# Machine-learning plan

Candidate features (only when sourced and documented): rainfall accumulation/intensity, elevation, slope, land cover, drainage proximity and historical flood occurrence.

Do not claim predictive accuracy until the model has been trained and evaluated on a held-out, relevant dataset. Prefer recall for identifying high-risk examples, while also reporting precision and false-positive rates.
